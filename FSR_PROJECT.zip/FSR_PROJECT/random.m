function qrand = random(x_map,y_map,z_map)
    
    qrand=[floor(rand*x_map), floor(rand*y_map) , floor(rand*z_map)];
    
end