m=1.2;
g = 9.81;  
Ix = 0.5;   
Iy = 0.5;
Iz = 0.9;
Ir = 0.005;
Om_r = 70; 
l = 0.25;  
d = 0.03;
m1 = 0.1;
Ts1 = 0.001;
Ts2 = 0.001;

data = [m;m1;Ix;Iy;Iz;Ir;Om_r;d;l;g;Ts1;Ts2];


x0 = 0;
y0 = 0;
z0 = 0;
dx0 = 0;
dy0 = 0;
dz0 = 0;
phi0 = 0;
theta0 = 0;
psi0 = 0;
p0 = 0;
q0 = 0;
r0 = 0;
tau_phi0 = 0;
tau_theta0 = 0;
tau_psi0 = 0;

init_state = [x0 y0 z0  dx0 dy0 dz0 phi0 theta0 psi0 p0 q0 r0 tau_phi0 tau_theta0 tau_psi0]';



A = zeros(15,15);
A(1:3,4:6) = eye(3);
A(4,8) = -g;
A(5,7) = g;
A(7:9,10:12) = eye(3);
A(10,13) = 1/Ix;
A(11,14) = 1/Iy;
A(12,15) = 1/Iz;
A(13,10) = -Ix/(Ts1*Ts2);
A(14,11) = -Iy/(Ts1*Ts2);
A(15,12) = -Iz/(Ts1*Ts2);
A(13:15,13:15) = -1/Ts1*eye(3);

B = zeros(15,7);
B(6,1) = -1;
B(4:6,5:7) = 1/m*eye(3);
B(13,2) = Ix/(Ts1*Ts2);
B(14,3) = Iy/(Ts1*Ts2);
B(15,4) = Iz/(Ts1*Ts2);

C = zeros(6,15);
C(1:3,1:3) = eye(3);
C(4:6,7:9) = eye(3);

D = zeros(6,7);


