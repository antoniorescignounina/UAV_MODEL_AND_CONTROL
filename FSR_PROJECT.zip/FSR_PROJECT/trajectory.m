%%TRAIETTORIA SCARA con profilo di velocità trapezoidale
%%DEFINIZIONE PUNTI E SPECIFICA DEI PUNTI DI VIA
vec_f = [  1   ,   1  ,    1; 
          70 ,    60 ,   30;  
          40 ,    90 ,   50;      
          16  ,   79 ,   51;  
          20 ,    60 ,   50;  
          24  ,   36 ,   47;  
          40 ,    40 ,   50;  
         117 ,    30 ,   39;  
         140 ,    40 ,   40;  
         139 ,    13 ,   50;  
         180 ,    60 ,   40; 
         172 ,    96 ,   78;  
         100 ,   100 ,  100;  
          90 ,   160 ,  100;  
          91 ,   192 ,  109;  
          40 ,   190 ,  100;  
           5 ,   185 ,  146;  
          10 ,   160 ,  100;  
          18 ,   115 ,  136;   
          40 ,   120 ,  150;  
          52 ,   120 ,  142;  
         140 ,   150 ,  120];

p=vec_f';

global numero_tratti t_s num_campione tempo_tratto

t_s=0.1; %settaggio del tempo di campionamento ad 1ms
tempo_tratto=10; %tempo impiegato per compiere un tratto
num_campione=tempo_tratto/t_s; %è il numero di campioni per tratto




%definizione dei tratti rettilinei e dei tratti circolari 
%tratto circolare 0, tratto rettilineo 1
percorso=ones(1,length(vec_f)-1); 
numero_tratti_rettilinei=length(vec_f)-1;
numero_tratti_circolari=0;
numero_tratti=numero_tratti_rettilinei+numero_tratti_circolari;


t=[]; %vettore tempo
tf=[]; %vettore tempo finale per ogni tratto
temp=0; %inizializzazione di una variabile atta ad indicare il tempo accumulato avanzando nel percorso

for i=1:1:numero_tratti
    t(i,:)=temp:t_s:tempo_tratto+temp; %vettore tempo relativo all'i-esimo tratto
    temp=temp+tempo_tratto; %temp si aggiorna,sommando al valore precedente il tempo_tratto
    tf(i)=t(i,end);
end

% 
% 
% %parametri circonferenza 5-6
% c1=(p(:,6)-p(:,5))/2; %centro circonferenza
% r1=norm(c1); %raggio circonferenza
% ang1=pi;
% 
% R1=eye(3);
% 
% %parametri circonferenza 6-7
% c2=(p(:,7)-p(:,6))/2; %centro circonferenza
% r2=norm(c2);%raggio circonferenza
% ang2=pi;
% R2=[cos(pi) 0 sin(pi);
%     0       1 0;
%     -sin(pi) 0 cos(pi)];
%     
% R2=R2*[cos(pi) -sin(pi) 0;
%       sin(pi) cos(pi)  0;
%       0       0        1];
%  
% % parametri circonferenza 7-8
% c3=(p(:,8)-p(:,7))/2; %centro circonferenza
% r3=norm(c3);%raggio circonferenza
% ang3=pi;
% R3=eye(3);
% 
% 
% % parametri circonferenza 11-10
% c4=(p(:,11)-p(:,10))/2; %centro circonferenza
% r4=norm(c4);%raggio circonferenza
% ang4=pi;
% 
% % R4=[cos(pi) -sin(pi) 0;
% %       sin(pi) cos(pi)  0;
% %       0       0        1];
%  R4=[cos(pi) -sin(pi) 0;
%      sin(pi) cos(pi) 0;
%      0       0       1];
% 
% % parametri circonferenza 11-12
% c5=(p(:,12)-p(:,11))/2; %centro circonferenza
% r5=norm(c5);%raggio circonferenza
% ang5=pi;
% 
%  R5=[cos(pi) 0 sin(pi);
%     0       1 0;
%     -sin(pi) 0 cos(pi)];
%     
% % parametri circonferenza 12-13
% c6=(p(:,13)-p(:,12))/2; %centro circonferenza
% r6=norm(c6);%raggio circonferenza
% ang6=pi;
% 
%  R6=[cos(pi) -sin(pi) 0;
%       sin(pi) cos(pi) 0;
%       0       0       1];
% 
% 
% % parametri circonferenza 13-14
% c7=(p(:,14)-p(:,13))/2; %centro circonferenza
% r7=norm(c7);%raggio circonferenza
% ang7=pi;
% 
%  R7=[cos(pi) 0 sin(pi);
%     0       1 0;
%     -sin(pi) 0 cos(pi)];
% 
% % parametri circonferenza 14-15
% c8=(p(:,15)-p(:,14))/2; %centro circonferenza
% r8=norm(c8);%raggio circonferenza
% ang8=pi;
% 
%  R8=[cos(pi) -sin(pi) 0;
%       sin(pi) cos(pi) 0;
%       0       0       1];
% 
% 
% c= [ c1 c2 c3 c4 c5 c6 c7 c8]; 
% r= [ r1; r2;r3; r4; r5; r6; r7; r8];
% ang=[ ang1; ang2; ang3; ang4;ang5; ang6; ang7; ang8];
% R=[ R1; R2; R3; R4; R5; R6; R7; R8];
   
%% Norme tratti
norme=[];
temp=1;

%tratto rettilineo e circolare, definizione della norma
for i=1:1:numero_tratti
%     if percorso(i)==1
        norme(i)=norm(p(:,i+1)-p(:,i));     
%     else
%         norme(i)=ang(temp)*r(temp);       
%         temp=temp+1;
%     end
end

%% Calcolo delle ascisse curvilinee

ddascissa_curvilinea=[];         %accelerazione ascissa curvilinea 
t_crociera=[];    %tempo di inizio tratto di crociera

for i=1:1:numero_tratti
    ddascissa_curvilinea_min=(4*abs(norme(i)))/(tempo_tratto^2);                                   
    ddascissa_curvilinea(i)=2.5*ddascissa_curvilinea_min; %l'accelerazione dell'ascissa curvilinea è posta pari a 2.5       
    t_crociera(i)=(tempo_tratto/2)-(1/2)*sqrt((tempo_tratto^2*ddascissa_curvilinea(i)-4*norme(i))/ddascissa_curvilinea(i)); 
end


%è possibile calcolare s ds dds con andamento trapezoidale

s_p= [];
ds_p=[];
dds_p=[];


for i=1:1:numero_tratti
    [sp,dsp,ddsp]=ascissacurvilinea(t_crociera(i),tempo_tratto,ddascissa_curvilinea(i),norme(i));
    
    s_p(i,:)=sp;
    ds_p(i,:)=dsp;
    dds_p(i,:)=ddsp;
end






% Calcolo delle ascisse curvilinee s(t), sp(t), spp(t)

S=[];
dS=[];
ddS=[];

%tempi di anticipo per i punti di via
delta_t1=0;
delta_t2=0;
delta_t3=0;

%tempi di anticipo in corrispondenza dei punti di via del percorso
Delta=[0 delta_t1 0 0 0 delta_t2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
for i=1:1:numero_tratti
    
    anticipo=sum(Delta(1:i));
    s_0= zeros(1,num_campione*(i-1)-anticipo);  
    s_norma=norme(i)*ones(1,num_campione*(numero_tratti-i)+anticipo);
    
    S(i,:)=[s_0 s_p(i,:) s_norma];
    dS(i,:)=[s_0 ds_p(i,:) 0*s_norma];
    ddS(i,:)=[s_0 dds_p(i,:) 0*s_norma];
    
end

%calcolo traiettoria


%posizione pt iniziale
xe=p(1,1);
ye=p(2,1);
ze=p(3,1);
%velocita pt iniziale
dxe=0;
dye=0;
dze=0;
%accelerazione pt iniziale
ddxe=0;
ddye=0;
ddze=0;

center_index=1;
rotation_matrix=1;

for i=1:1:numero_tratti
    diff=p(:,i+1)-p(:,i);
    if percorso(i)==1     %tratto rettilineo 

        
        xe_prec=(S(i,:)/norme(i))*diff(1);
        xe=xe+xe_prec;
        
        ye_prec=(S(i,:)/norme(i))*diff(2);
        ye=ye+ye_prec;
        
        ze_prec=(S(i,:)/norme(i))*diff(3);
        ze=ze+ze_prec;
        
        dxe_prec=(dS(i,:)/norme(i))*diff(1);
        dxe=dxe+dxe_prec;
        
        dye_prec=(dS(i,:)/norme(i))*diff(2);
        dye=dye+dye_prec;
        
        dze_prec=(dS(i,:)/norme(i))*diff(3);
        dze=dze+dze_prec;
        
        ddxe_prec=(ddS(i,:)/norme(i))*diff(1);
        ddxe=ddxe+ddxe_prec;
        
        ddye_prec=(ddS(i,:)/norme(i))*diff(2);
        ddye=ddye+ddye_prec;
        
        ddze_prec=(ddS(i,:)/norme(i))*diff(3);
        ddze=ddze+ddze_prec;
        
    else %tratto curvilineo  
        anticipo=sum(Delta(1,:));
        zero_c=zeros(1,num_campione*(i-1)-anticipo);
        norme_c=ones(1,num_campione*(numero_tratti-i)+anticipo);
        
        notorientated_pos=[r(center_index)*cos(s_p(i,:)/r(center_index));
                             r(center_index)*sin(s_p(i,:)/r(center_index));
                             zeros(1,length(s_p(i,:)))];
        orientated_pos=[];
        for ii=1:1:length(notorientated_pos(1,:))                  
            orientated_pos=[orientated_pos   R(rotation_matrix:rotation_matrix+2,:)*notorientated_pos(:,ii)];
        end
        
        %posizioni
        xe_circ=c(1,center_index)+orientated_pos(1,:);
        ye_circ=c(2,center_index)+orientated_pos(2,:);
        ze_circ=c(3,center_index)+orientated_pos(3,:);
        
        xe_prec=[zero_c xe_circ diff(1)*norme_c];
        xe=xe+xe_prec;
        
        ye_prec=[zero_c ye_circ diff(2)*norme_c];
        ye=ye+ye_prec;
        
        ze_prec=[zero_c ze_circ diff(3)*norme_c];
        ze=ze+ze_prec;
        
        %velocità 
        notorientated_vel=[-ds_p(i,:).*sin(s_p(i,:)/r(center_index));
                        ds_p(i,:).*cos(s_p(i,:)/r(center_index));
                        zeros(1,length(s_p(i,:)))];
                    
        orientated_vel=[];
        for y=1:1:length(notorientated_vel(1,:))
            orientated_vel=[orientated_vel R(rotation_matrix:rotation_matrix+2,:)*notorientated_vel(:,y)];
        end
     
        dxe_circ=orientated_vel(1,:);
        dye_circ=orientated_vel(2,:);
        dze_circ=orientated_vel(3,:);
        
        dxe_prec=[zero_c dxe_circ 0*norme_c];
        dxe=dxe+dxe_prec;
        
        dye_prec=[zero_c dye_circ 0*norme_c];
        dye=dye+dye_prec;

        dze_prec=[zero_c dze_circ 0*norme_c];
        dze=dze+dze_prec;

        %accelerazione formula 4.45 pag 190
        notorientated_acc=[-(ds_p(i,:).^2).*cos(s_p(i,:)/r(center_index))/r(center_index)-dds_p(i,:).*sin(s_p(i,:)/r(center_index));
              -(ds_p(i,:).^2).*sin(s_p(i,:)/r(center_index))/r(center_index)+dds_p(i,:).*cos(s_p(i,:)/r(center_index));
                        zeros(1,length(s_p(i,:)))];
        orientated_acc=[];
        for y=1:1:length(notorientated_acc(1,:))
              orientated_acc=[orientated_acc   R(rotation_matrix:rotation_matrix+2,:)*notorientated_acc(:,y)];
        end
        
        ddxe_circ=orientated_acc(1,:);
        ddye_circ=orientated_acc(2,:);
        ddze_circ=orientated_acc(3,:);        

        ddxe_prec=[zero_c ddxe_circ 0*norme_c];
        ddye_prec=[zero_c ddye_circ 0*norme_c];
        ddze_prec=[zero_c ddze_circ 0*norme_c];
        
        ddxe=ddxe+ddxe_prec;
        ddye=ddye+ddye_prec;
        ddze=ddze+ddze_prec;
        
        center_index=center_index+1;
        rotation_matrix=rotation_matrix+3;
        
            
    end 
end



fprintf('TRAIETTORIA\n')



 %plottaggio posizione

figure()
sgtitle('posizione end-effector')
plot_time=linspace(0,10+numero_tratti*tempo_tratto,1+numero_tratti*num_campione);

subplot(3,1,1)
plot(xe)
% xlim([0 30])
grid on
title('x_e')

subplot(3,1,2)
plot(ye)
% xlim([0 30])
grid on
title('y_e')

subplot(3,1,3)
plot(ze)
% xlim([0 30])
grid on
title('z_e')


%plottaggio velocita'
figure()
sgtitle('velocità end-effectore')

subplot(3,1,1)
plot(dxe)
% xlim([0 30])
grid on
title('dx_e')

subplot(3,1,2)
plot(dye)
% xlim([0 30])
grid on
title('dy_e')

subplot(3,1,3)
plot(dze)
% xlim([0 30])
grid on
title('dz_e')

%plottaggio accelerazione
figure()
sgtitle('accelerazione end-effectore')

subplot(3,1,1)
plot(ddxe)
% xlim([0 30])
grid on
title('ddx_e')

subplot(3,1,2)
plot(ddye)
% xlim([0 30])
grid on
title('ddy_e')

subplot(3,1,3)
plot(ddze)
% xlim([0 30])
grid on
title('ddz_e')


%percorso nel piano
figure()
axis equal
% ac=0;
% bc=0;
% r=1;
% angle=linspace(0,2*pi);
% A=r*cos(angle)+ac;
% B=r*sin(angle)+bc;
 plot(xe,ye);
% hold on
% plot(A,B,'b--');
% axis([-1 1 -1 1]);
hold on
grid on
for i=1:1:numero_tratti
    plot(p(1,i),p(2,i),'r+');
    
end
title('percorso nel piano x-y')
xlabel('asse x')
ylabel('asse y')


%percorso nello spazio
figure()
axis equal
plot3(xe,ye,ze)

hold on
grid on
for i=1:1:length(vec_f)
    plot3(p(1,i),p(2,i),p(3,i),'r+');
end
title('percorso nello spazio')
xlabel('asse x')
ylabel('asse y')
zlabel('asse z')





time_vector= t_s: t_s: length(xe)*t_s;

pb_des=[time_vector' xe' ye' ze'];

dpb_des=[time_vector' dxe' dye' dze'];

ddpb_des=[time_vector' ddxe' ddye' ddze'];


