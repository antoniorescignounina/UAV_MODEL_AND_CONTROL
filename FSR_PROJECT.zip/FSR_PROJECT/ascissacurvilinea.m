function [s_p,ds_p,dds_p]=ascissacurvilinea(t_crociera,tf,ddq_c,norma)
global t_s
t_crociera=round(1000*t_crociera)/1000;

%intervalli
tratto_acc = 0:t_s:t_crociera;
tratto_crociera = t_crociera+t_s:t_s:tf-t_crociera;
tratto_dec= tf-t_crociera+t_s:t_s:tf;

%posizione
s_p_acc =0.5*ddq_c*tratto_acc.^2;
s_p_crociera=ddq_c*t_crociera*(tratto_crociera-0.5*t_crociera);
s_p_dec=norma-0.5*ddq_c*(tf-tratto_dec).^2;

s_p=[s_p_acc s_p_crociera s_p_dec];

%velocità
ds_p_acc=ddq_c*tratto_acc;
ds_p_crociera=ddq_c*t_crociera*ones(1,length(tratto_crociera));
ds_p_dec=ddq_c*(tf-tratto_dec);

ds_p=[ds_p_acc ds_p_crociera ds_p_dec];

%accelerazione
dds_p_acc=ddq_c*ones(1,length(tratto_acc));
dds_p_crociera=zeros(1,length(tratto_crociera));
dds_p_dec=-ddq_c*ones(1,length(tratto_dec));

dds_p=[dds_p_acc dds_p_crociera dds_p_dec];


end