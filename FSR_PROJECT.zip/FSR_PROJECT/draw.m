function draw(points_rdmap,vec,tree,sol_found)

if (sol_found == 1) 

for p =1:1:length(tree(:,1))
    
f_c_1 = points_rdmap(tree(p,1),1);
s_c_1 = points_rdmap (tree(p,1),2);
t_c_1 = points_rdmap (tree(p,1),3);

f_c_2 = points_rdmap(tree(p,2),1);
s_c_2 = points_rdmap (tree(p,2),2);
t_c_2 = points_rdmap (tree(p,2),3);
 
% hold on
%  plot3( f_c_1,s_c_1, t_c_1, 'x', 'Color',  [0 0.4470 0.7410])
%  hold on
%  plot3(f_c_2,s_c_2, t_c_2, 'x', 'Color',  [0 0.4470 0.7410])
% %  hold on
%  line([f_c_1 , f_c_2], [s_c_1 , s_c_2], [t_c_1 , t_c_2], 'Color', 'g')   
 
end

for p=1:1: length(vec)-1

point_one = points_rdmap(vec(p),:);
point_two = points_rdmap(vec(p+1),:);

hold on 
line([point_one(1), point_two(1)], [point_one(2), point_two(2)], [point_one(3), point_two(3)], 'Color', 'r', 'LineWidth', 3)


end

else
    display('Solution not found!')
    end
        end