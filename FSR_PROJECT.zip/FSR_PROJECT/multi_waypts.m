clear all
close all
clc  

%%%%Waypoints%%%%%%%%%%%%%%%

path(1,:)  =  [  1    1    1];
path(2,:)  =  [ 70   60   30];
path(3,:)  =  [ 40   90   50];
path(4,:)  =  [ 20   60   50];
path(5,:)  =  [ 40   40   50];
path(6,:)  =  [ 140  40   40];
path(7,:)  =  [180   60   40];
path(8,:)  =  [100  100  100];
path(9,:)  =  [ 90  160  100];
path(10,:)  =  [ 40  190  100];
path(11,:) =  [ 10  160  100];
path(12,:) =  [ 40  120  150];
path(13,:) =  [140  150  120];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sol_found = 0;
q_start = path(1,:);
q_final = path(13,:);

omap3D = occupancyMap3D;
occ_map(omap3D,q_start, q_final);

for p =2:1:length(path)-1
    pt = path(p,:);
 plot3(pt(1), pt(2), pt(3),'bo','MarkerFaceColor','yellow','MarkerSize',8)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

iter  = 100;
ds    = 100 ;
vec_f = [q_start];

points_rdmap = q_rand_gen(iter,q_start,  q_final,omap3D);

for k =1:1:length(path)-1

sol_found = 0;

points_rdmap(1,:)   = path(k,:);
points_rdmap(end,:) = path(k+1,:);

tree = seg_gen(ds,points_rdmap,omap3D);

[vec ,  sol_found] = A_star(points_rdmap,tree);

if(sol_found ==1)

for  i =1:1:length(vec)
tmp(i,:) = points_rdmap(vec(i),:);
end

if(vec_f(end,:) == tmp(1,:))
    tmp(1,:) = [];
end
vec_f = [vec_f;tmp];

end


draw(points_rdmap,vec,tree,sol_found);

if(sol_found == 0)
    close all
    clear final_points
    break
end

end



