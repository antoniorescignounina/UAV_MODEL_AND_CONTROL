function pts = segm(first, second)

t = 100;

seg = first(1) : (second(1) - first(1))/t : second(1);
if(length(seg) == 0)
    seg = first(1)*ones(1,t+1);
end

seg1 = first(2) : (second(2) - first(2))/t : second(2);
if(length(seg1) == 0)
    seg1 = first(2)*ones(1,t+1);
end

seg2 = first(3) : (second(3) - first(3))/t : second(3);
if(length(seg2) == 0)
    seg2 = first(3)*ones(1,t+1);
end


for k = 1:1:length(seg)
pts(k,:) = [seg(k)  seg1(k)  seg2(k)];
end





end