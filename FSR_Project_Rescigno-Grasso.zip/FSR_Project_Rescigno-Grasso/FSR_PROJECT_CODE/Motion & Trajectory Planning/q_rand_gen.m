function [points_rdmap] = q_rand_gen(iter,q_start, q_final,omap3D)


global mapWidth
global mapLength
global mapHeight

points_rdmap(1,:) = [q_start(1) q_start(2) q_start(3)];

 s=2;

 for i=1:1:iter

qrand = random(mapWidth, mapLength, mapHeight);

  if( checkOccupancy(omap3D, qrand) == -1)
      points_rdmap(s,:) = [qrand(1) qrand(2) qrand(3)];
      s = s+1;
  end

 end

 points_rdmap(s,:) = [q_final(1) q_final(2) q_final(3)];
clear length


end