function [ tree_dfs , sol_found] = A_star(points_rdmap,tree)


%%%%%%%%%%ADJ MATRIX%%%%%%%%%%%%%%%%
ADJ = zeros(length(points_rdmap), length(points_rdmap) );

for p = 1:1:length(points_rdmap)

    for s=1:1:length(tree)
        if(tree(s,1) == p)
            ADJ(p,tree(s,2)) =distance_3d(points_rdmap(p,:) , points_rdmap(tree(s,2),:));

        end

    end


end
goal = length(points_rdmap);
sol_found = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 for i =1:1:length(ADJ(1,:))
 nodes(i,:) = [i 0];
 end    

OPEN  =[];
final = [];
OPEN(1,:) = [1 0 0];
nodes(1,2) = 1;

N_best = OPEN(1,:);
final(end+1,:)  = [1 0 0];
OPEN(1,:) = [];

for p =1:1:length(ADJ(1,:))
    if(ADJ(N_best(1),p) > 0)
        OPEN(end+1,:)  =  [p N_best(1)  ADJ(N_best(1),p) ];
        final(end+1,:) =  [p N_best(1)  ADJ(N_best(1),p)];
        nodes(p,2) =1;
    end
end

OPEN = sortrows(OPEN,3);

%%%%%%%%%%%%%%%%%%%%%%


while(1)

if(length(OPEN(:,1)) == 0)
    break
end

N_best = OPEN(1,:);


if (N_best(1) == goal)
    sol_found =1;
    break
end

OPEN(1,:) = [];

for p =1:1:length(ADJ(1,:))
    if(ADJ(N_best(1),p) > 0)

        if(nodes(p,2) == 0 )

        OPEN(end+1,:) =  [p N_best(1)  (ADJ(N_best(1),p) + N_best(3)) ];
        final(end+1,:) = [p N_best(1)  (ADJ(N_best(1),p) + N_best(3))];
        nodes(p,2) =1;

        else

            for n=1:1:length(final) 
                if(final(n) == p)
                    cost_p = final(n,3);
                end
            end

         flag =  N_best(3) + ADJ(N_best(1), p);
         if(flag < cost_p )
              for n=1:1:length(final) 
                if(final(n) == p)
                    final(n,2) = N_best(1);
                end
            end

        end

    end
end
end
OPEN = sortrows(OPEN,3);
end


if(sol_found == 1)

ind = goal;
tree_dfs(1) = goal;




while (ind > 1)

for n=1:1:length(final) 

    if(final(n,1) == ind)

        ind = final(n,2);
        tree_dfs(end+1) = final(n,2);
        
     end
        end    
            end
tree_dfs = flip(tree_dfs);

else 
tree_dfs = [0 0 0];
end




end