function [tree] = seg_gen(ds, points_rdmap,omap3D)
ret =1;

indx = [];
indx(1,:) = [-1 -1];

for j = 1:1:length(points_rdmap)

    cnd = points_rdmap(j,:);

    for m  = 1:1:length(points_rdmap)

        flag = 0;

        cnd_s = points_rdmap(m,:);

        ds_i = distance_3d(cnd,cnd_s);
            
            for  v =1:1:length(indx(:,1))
 
               if(indx(v,2) == j && indx(v,1) == m)
                        flag = 1;
               end

             end
            if(ds_i > 0 && ds_i < ds && flag ==0 )

                indx(ret,:)=[j m];
                ret = ret+1;

            end


end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l =1 ;
for p = 1:1:length(indx)

    first = points_rdmap(indx(p,1),:);
   second = points_rdmap(indx(p,2),:);
   ok = 1;

pts = segm(first,second);

for k = 1:1:length(pts)
point = pts(k,:);

    if(checkOccupancy(omap3D, point) == 1)
        ok = 0;
        break
        
    end



end

if (ok ==1)
    tree(l,:) = [ indx(p,1) indx(p,2)];
    l=l+1;
    
end

end

end