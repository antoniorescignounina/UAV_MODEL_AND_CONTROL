clear all
close all
clc                                                                                                                                  


q_start = [ 1 1 1];
q_final = [140 150 120];

iter =100;
sol_found = 0;
ds = 100 ;

omap3D = occupancyMap3D;

occ_map(omap3D,q_start, q_final);

points_rdmap = q_rand_gen(iter,q_start, q_final,omap3D);

tree = seg_gen(ds,points_rdmap,omap3D);

[vec ,  sol_found] = A_star(points_rdmap,tree);

draw(points_rdmap,vec,tree,sol_found);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if(sol_found ==1)
for  i =1:1:length(vec)
final_points(i,:) = points_rdmap(vec(i),:);
end


end
