iter =500;
sol_found = 0;
ds = 150 ;
q_start = [ 1 1 1];
q_final = [140 150 120];

omap3D = occupancyMap3D;

numofobstacles=6;

global mapWidth
global mapLength
global mapHeight

mapWidth = 200;
mapLength = 200;
mapHeight = 200;



width       =   [ 25  30   5  60  50  20];
length      =   [ 25   6  40  12  50  20];
height      =   [ 90 180 145 130 200  70];
xPosition   =   [ 25  70 180 100  25 150];
yPosition   =   [ 50  25 145 111 130  50];

for i=1:1:numofobstacles
[xObstacle,yObstacle,zObstacle] = meshgrid(xPosition(i):xPosition(i)+width(i),yPosition(i):yPosition(i)+length(i),0:height(i));
xyzObstacles = [xObstacle(:) yObstacle(:) zObstacle(:)];

setOccupancy(omap3D,xyzObstacles,1)


end
[xGround,yGround,zGround] = meshgrid(0:mapWidth,0:mapLength,0);
xyzGround = [xGround(:) yGround(:) zGround(:)];
setOccupancy(omap3D,xyzGround,1)

figure("Name","3D Occupancy Map")
fig.Color = [0 0.8 0.8];

show(omap3D)
hold on 
plot3(q_start(1), q_start(2), q_start(3),'bo','MarkerFaceColor','yellow','MarkerSize',8)
hold on 
plot3(q_final(1), q_final(2), q_final(3),'bo','MarkerFaceColor','yellow','MarkerSize',8)
hold on
% % %FOR THE PASSIVITY
% for i=1:1:2100
%     plot3(xe(i),ye(i),ze(i),'ro');
%     hold on
%     plot3(out.x.Data(i),out.y.Data(i),out.z.Data(i),'bo');
%     drawnow
% end


%for the PID

for i=1:10:21000
    hold on
    plot3(x.Data(i),y.Data(i),z.Data(i),'bo');
   drawnow
end
   hold on
   plot3(xe,ye,ze,'ro');
