
% Apparent Inertia
m_admittance = 1.2;
M = eye(3)*m_admittance;

% Desired Damping 
d_admittance =0.9;
Damp = eye(3)*d_admittance;

% Desired Stiffness
stiff = 0.9;
K = stiff*eye(3);

A_admittance = [zeros(3,3), eye(3); 
        -inv(M)*K, -inv(M)*Damp];
    
B_admittance = [zeros(3,3), zeros(3,3);
        inv(M)*K, inv(M)];
    
C_admittance = [eye(3), zeros(3,3)];

D_admittance = zeros(3,6);



