clear all;
close all;
clc;
%  multi_waypts
trajectory
Linearization_and_dyn_model 
Admittance_control
Kalman_filter
    p = menu('Choose the problem: 1 for PID attitude and position control and 2 for passivity based control', 1,2);

if p==1
control_with_kalman
else
passivity_based
end